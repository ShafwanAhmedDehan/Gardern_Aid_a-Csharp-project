﻿
namespace Garden_AID
{
    partial class ManageProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageProfile));
            this.ManagePrfSideBar = new System.Windows.Forms.Panel();
            this.locationVisiable = new System.Windows.Forms.TextBox();
            this.NameDisplay = new System.Windows.Forms.TextBox();
            this.profilePicshower = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.AdrsView = new System.Windows.Forms.TextBox();
            this.genderView = new System.Windows.Forms.TextBox();
            this.numberDisplay = new System.Windows.Forms.TextBox();
            this.emailDisplayprf = new System.Windows.Forms.TextBox();
            this.FnDisplay = new System.Windows.Forms.TextBox();
            this.AddressView = new System.Windows.Forms.Label();
            this.genderDisplay = new System.Windows.Forms.Label();
            this.phoneNodisplay = new System.Windows.Forms.Label();
            this.EmailDisplay = new System.Windows.Forms.Label();
            this.NameLebel = new System.Windows.Forms.Label();
            this.ChangeName = new System.Windows.Forms.Label();
            this.EmailChange = new System.Windows.Forms.Label();
            this.changeMobile = new System.Windows.Forms.Label();
            this.changeAddress = new System.Windows.Forms.Label();
            this.nameInput = new System.Windows.Forms.TextBox();
            this.LastNameinput = new System.Windows.Forms.TextBox();
            this.Emailinput = new System.Windows.Forms.TextBox();
            this.PhoneNumberinput = new System.Windows.Forms.TextBox();
            this.AddressInput = new System.Windows.Forms.TextBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.Submitbutton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ManagePrfSideBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicshower)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ManagePrfSideBar
            // 
            this.ManagePrfSideBar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ManagePrfSideBar.Controls.Add(this.locationVisiable);
            this.ManagePrfSideBar.Controls.Add(this.NameDisplay);
            this.ManagePrfSideBar.Controls.Add(this.profilePicshower);
            this.ManagePrfSideBar.Location = new System.Drawing.Point(13, 13);
            this.ManagePrfSideBar.Name = "ManagePrfSideBar";
            this.ManagePrfSideBar.Size = new System.Drawing.Size(212, 648);
            this.ManagePrfSideBar.TabIndex = 0;
            // 
            // locationVisiable
            // 
            this.locationVisiable.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.locationVisiable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.locationVisiable.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.locationVisiable.Location = new System.Drawing.Point(17, 309);
            this.locationVisiable.Name = "locationVisiable";
            this.locationVisiable.Size = new System.Drawing.Size(175, 22);
            this.locationVisiable.TabIndex = 2;
            this.locationVisiable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NameDisplay
            // 
            this.NameDisplay.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.NameDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NameDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NameDisplay.Location = new System.Drawing.Point(17, 268);
            this.NameDisplay.Name = "NameDisplay";
            this.NameDisplay.Size = new System.Drawing.Size(175, 22);
            this.NameDisplay.TabIndex = 1;
            this.NameDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // profilePicshower
            // 
            this.profilePicshower.Image = ((System.Drawing.Image)(resources.GetObject("profilePicshower.Image")));
            this.profilePicshower.Location = new System.Drawing.Point(17, 142);
            this.profilePicshower.Name = "profilePicshower";
            this.profilePicshower.Size = new System.Drawing.Size(175, 104);
            this.profilePicshower.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.profilePicshower.TabIndex = 0;
            this.profilePicshower.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.AdrsView);
            this.panel1.Controls.Add(this.genderView);
            this.panel1.Controls.Add(this.numberDisplay);
            this.panel1.Controls.Add(this.emailDisplayprf);
            this.panel1.Controls.Add(this.FnDisplay);
            this.panel1.Controls.Add(this.AddressView);
            this.panel1.Controls.Add(this.genderDisplay);
            this.panel1.Controls.Add(this.phoneNodisplay);
            this.panel1.Controls.Add(this.EmailDisplay);
            this.panel1.Controls.Add(this.NameLebel);
            this.panel1.Location = new System.Drawing.Point(282, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(510, 331);
            this.panel1.TabIndex = 1;
            // 
            // AdrsView
            // 
            this.AdrsView.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.AdrsView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AdrsView.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AdrsView.Location = new System.Drawing.Point(150, 270);
            this.AdrsView.Name = "AdrsView";
            this.AdrsView.Size = new System.Drawing.Size(266, 22);
            this.AdrsView.TabIndex = 9;
            // 
            // genderView
            // 
            this.genderView.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.genderView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.genderView.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.genderView.Location = new System.Drawing.Point(150, 210);
            this.genderView.Name = "genderView";
            this.genderView.Size = new System.Drawing.Size(225, 22);
            this.genderView.TabIndex = 8;
            // 
            // numberDisplay
            // 
            this.numberDisplay.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.numberDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numberDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.numberDisplay.Location = new System.Drawing.Point(150, 150);
            this.numberDisplay.Name = "numberDisplay";
            this.numberDisplay.Size = new System.Drawing.Size(225, 22);
            this.numberDisplay.TabIndex = 7;
            // 
            // emailDisplayprf
            // 
            this.emailDisplayprf.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.emailDisplayprf.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.emailDisplayprf.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.emailDisplayprf.Location = new System.Drawing.Point(150, 90);
            this.emailDisplayprf.Name = "emailDisplayprf";
            this.emailDisplayprf.Size = new System.Drawing.Size(266, 22);
            this.emailDisplayprf.TabIndex = 6;
            // 
            // FnDisplay
            // 
            this.FnDisplay.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.FnDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FnDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FnDisplay.Location = new System.Drawing.Point(118, 30);
            this.FnDisplay.Name = "FnDisplay";
            this.FnDisplay.Size = new System.Drawing.Size(194, 22);
            this.FnDisplay.TabIndex = 5;
            // 
            // AddressView
            // 
            this.AddressView.AutoSize = true;
            this.AddressView.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AddressView.Location = new System.Drawing.Point(14, 271);
            this.AddressView.Name = "AddressView";
            this.AddressView.Size = new System.Drawing.Size(70, 21);
            this.AddressView.TabIndex = 4;
            this.AddressView.Text = "Address";
            // 
            // genderDisplay
            // 
            this.genderDisplay.AutoSize = true;
            this.genderDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.genderDisplay.Location = new System.Drawing.Point(18, 211);
            this.genderDisplay.Name = "genderDisplay";
            this.genderDisplay.Size = new System.Drawing.Size(64, 21);
            this.genderDisplay.TabIndex = 3;
            this.genderDisplay.Text = "Gender";
            // 
            // phoneNodisplay
            // 
            this.phoneNodisplay.AutoSize = true;
            this.phoneNodisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.phoneNodisplay.Location = new System.Drawing.Point(18, 151);
            this.phoneNodisplay.Name = "phoneNodisplay";
            this.phoneNodisplay.Size = new System.Drawing.Size(82, 21);
            this.phoneNodisplay.TabIndex = 2;
            this.phoneNodisplay.Text = "Phone No";
            // 
            // EmailDisplay
            // 
            this.EmailDisplay.AutoSize = true;
            this.EmailDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.EmailDisplay.Location = new System.Drawing.Point(18, 91);
            this.EmailDisplay.Name = "EmailDisplay";
            this.EmailDisplay.Size = new System.Drawing.Size(48, 21);
            this.EmailDisplay.TabIndex = 1;
            this.EmailDisplay.Text = "Email";
            // 
            // NameLebel
            // 
            this.NameLebel.AutoSize = true;
            this.NameLebel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NameLebel.Location = new System.Drawing.Point(18, 31);
            this.NameLebel.Name = "NameLebel";
            this.NameLebel.Size = new System.Drawing.Size(86, 21);
            this.NameLebel.TabIndex = 0;
            this.NameLebel.Text = "Full Name ";
            // 
            // ChangeName
            // 
            this.ChangeName.AutoSize = true;
            this.ChangeName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ChangeName.Location = new System.Drawing.Point(282, 383);
            this.ChangeName.Name = "ChangeName";
            this.ChangeName.Size = new System.Drawing.Size(112, 21);
            this.ChangeName.TabIndex = 2;
            this.ChangeName.Text = "Change Name";
            this.ChangeName.Click += new System.EventHandler(this.ChangeName_Click);
            // 
            // EmailChange
            // 
            this.EmailChange.AutoSize = true;
            this.EmailChange.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.EmailChange.Location = new System.Drawing.Point(282, 437);
            this.EmailChange.Name = "EmailChange";
            this.EmailChange.Size = new System.Drawing.Size(145, 21);
            this.EmailChange.TabIndex = 3;
            this.EmailChange.Text = "Add/Change Email";
            this.EmailChange.Click += new System.EventHandler(this.EmailChange_Click);
            // 
            // changeMobile
            // 
            this.changeMobile.AutoSize = true;
            this.changeMobile.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.changeMobile.Location = new System.Drawing.Point(282, 493);
            this.changeMobile.Name = "changeMobile";
            this.changeMobile.Size = new System.Drawing.Size(179, 21);
            this.changeMobile.TabIndex = 4;
            this.changeMobile.Text = "Add/Change Phone No";
            this.changeMobile.Click += new System.EventHandler(this.changeMobile_Click);
            // 
            // changeAddress
            // 
            this.changeAddress.AutoSize = true;
            this.changeAddress.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.changeAddress.Location = new System.Drawing.Point(282, 551);
            this.changeAddress.Name = "changeAddress";
            this.changeAddress.Size = new System.Drawing.Size(129, 21);
            this.changeAddress.TabIndex = 5;
            this.changeAddress.Text = "Change Address";
            this.changeAddress.Click += new System.EventHandler(this.changeAddress_Click);
            // 
            // nameInput
            // 
            this.nameInput.BackColor = System.Drawing.SystemColors.Control;
            this.nameInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nameInput.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nameInput.Location = new System.Drawing.Point(400, 383);
            this.nameInput.Name = "nameInput";
            this.nameInput.PlaceholderText = "First name";
            this.nameInput.Size = new System.Drawing.Size(194, 22);
            this.nameInput.TabIndex = 6;
            // 
            // LastNameinput
            // 
            this.LastNameinput.BackColor = System.Drawing.SystemColors.Control;
            this.LastNameinput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.LastNameinput.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LastNameinput.Location = new System.Drawing.Point(600, 383);
            this.LastNameinput.Name = "LastNameinput";
            this.LastNameinput.PlaceholderText = "Last name";
            this.LastNameinput.Size = new System.Drawing.Size(192, 22);
            this.LastNameinput.TabIndex = 7;
            // 
            // Emailinput
            // 
            this.Emailinput.BackColor = System.Drawing.SystemColors.Control;
            this.Emailinput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Emailinput.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Emailinput.Location = new System.Drawing.Point(448, 437);
            this.Emailinput.Name = "Emailinput";
            this.Emailinput.PlaceholderText = "Enter email";
            this.Emailinput.Size = new System.Drawing.Size(344, 22);
            this.Emailinput.TabIndex = 8;
            // 
            // PhoneNumberinput
            // 
            this.PhoneNumberinput.BackColor = System.Drawing.SystemColors.Control;
            this.PhoneNumberinput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PhoneNumberinput.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PhoneNumberinput.Location = new System.Drawing.Point(484, 493);
            this.PhoneNumberinput.Name = "PhoneNumberinput";
            this.PhoneNumberinput.PlaceholderText = "Enter new number";
            this.PhoneNumberinput.Size = new System.Drawing.Size(235, 22);
            this.PhoneNumberinput.TabIndex = 9;
            // 
            // AddressInput
            // 
            this.AddressInput.BackColor = System.Drawing.SystemColors.Control;
            this.AddressInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AddressInput.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AddressInput.Location = new System.Drawing.Point(448, 551);
            this.AddressInput.Name = "AddressInput";
            this.AddressInput.PlaceholderText = "Enter new address";
            this.AddressInput.Size = new System.Drawing.Size(271, 22);
            this.AddressInput.TabIndex = 10;
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BackButton.FlatAppearance.BorderSize = 0;
            this.BackButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BackButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackButton.Location = new System.Drawing.Point(700, 623);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(91, 35);
            this.BackButton.TabIndex = 0;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // Submitbutton
            // 
            this.Submitbutton.BackColor = System.Drawing.SystemColors.Desktop;
            this.Submitbutton.FlatAppearance.BorderSize = 0;
            this.Submitbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Submitbutton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Submitbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Submitbutton.Location = new System.Drawing.Point(591, 623);
            this.Submitbutton.Name = "Submitbutton";
            this.Submitbutton.Size = new System.Drawing.Size(91, 35);
            this.Submitbutton.TabIndex = 12;
            this.Submitbutton.Text = "Submit";
            this.Submitbutton.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(318, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(162, 22);
            this.textBox1.TabIndex = 10;
            // 
            // ManageProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(831, 673);
            this.Controls.Add(this.Submitbutton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.AddressInput);
            this.Controls.Add(this.PhoneNumberinput);
            this.Controls.Add(this.Emailinput);
            this.Controls.Add(this.LastNameinput);
            this.Controls.Add(this.nameInput);
            this.Controls.Add(this.changeAddress);
            this.Controls.Add(this.changeMobile);
            this.Controls.Add(this.EmailChange);
            this.Controls.Add(this.ChangeName);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ManagePrfSideBar);
            this.Name = "ManageProfile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ManageProfile";
            this.Load += new System.EventHandler(this.ManageProfile_Load);
            this.ManagePrfSideBar.ResumeLayout(false);
            this.ManagePrfSideBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicshower)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel ManagePrfSideBar;
        private System.Windows.Forms.TextBox locationVisiable;
        private System.Windows.Forms.TextBox NameDisplay;
        private System.Windows.Forms.PictureBox profilePicshower;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox AdrsView;
        private System.Windows.Forms.TextBox genderView;
        private System.Windows.Forms.TextBox numberDisplay;
        private System.Windows.Forms.TextBox emailDisplayprf;
        private System.Windows.Forms.TextBox FnDisplay;
        private System.Windows.Forms.Label AddressView;
        private System.Windows.Forms.Label genderDisplay;
        private System.Windows.Forms.Label phoneNodisplay;
        private System.Windows.Forms.Label EmailDisplay;
        private System.Windows.Forms.Label NameLebel;
        private System.Windows.Forms.Label ChangeName;
        private System.Windows.Forms.Label EmailChange;
        private System.Windows.Forms.Label changeMobile;
        private System.Windows.Forms.Label changeAddress;
        private System.Windows.Forms.TextBox nameInput;
        private System.Windows.Forms.TextBox LastNameinput;
        private System.Windows.Forms.TextBox Emailinput;
        private System.Windows.Forms.TextBox PhoneNumberinput;
        private System.Windows.Forms.TextBox AddressInput;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button Submitbutton;
        private System.Windows.Forms.TextBox textBox1;
    }
}