﻿
namespace Garden_AID
{
    partial class Homapage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Homapage));
            this.HomePagebutton01 = new System.Windows.Forms.Button();
            this.OptionPanelHomePage = new System.Windows.Forms.Panel();
            this.PaymentUpdate = new System.Windows.Forms.Button();
            this.Package_Update = new System.Windows.Forms.Button();
            this.Dashboard = new System.Windows.Forms.Button();
            this.Message = new System.Windows.Forms.Button();
            this.Notification = new System.Windows.Forms.Button();
            this.HomePagebutton02 = new System.Windows.Forms.Button();
            this.HomePageButton04 = new System.Windows.Forms.Button();
            this.HomePagebutton03 = new System.Windows.Forms.Button();
            this.HomePageButton05 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.ExitButton = new System.Windows.Forms.PictureBox();
            this.OptionView = new System.Windows.Forms.Panel();
            this.logoutbutton = new System.Windows.Forms.Button();
            this.ManagePrf = new System.Windows.Forms.Button();
            this.ViewProfile = new System.Windows.Forms.Button();
            this.dataRegain = new System.Windows.Forms.DataGridView();
            this.OptionPanelHomePage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ExitButton)).BeginInit();
            this.OptionView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataRegain)).BeginInit();
            this.SuspendLayout();
            // 
            // HomePagebutton01
            // 
            this.HomePagebutton01.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.HomePagebutton01.FlatAppearance.BorderSize = 0;
            this.HomePagebutton01.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.HomePagebutton01.Image = ((System.Drawing.Image)(resources.GetObject("HomePagebutton01.Image")));
            this.HomePagebutton01.Location = new System.Drawing.Point(164, 112);
            this.HomePagebutton01.Name = "HomePagebutton01";
            this.HomePagebutton01.Size = new System.Drawing.Size(172, 110);
            this.HomePagebutton01.TabIndex = 0;
            this.HomePagebutton01.Text = "Indoor";
            this.HomePagebutton01.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.HomePagebutton01.UseVisualStyleBackColor = false;
            this.HomePagebutton01.Click += new System.EventHandler(this.HomePagebutton01_Click);
            // 
            // OptionPanelHomePage
            // 
            this.OptionPanelHomePage.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.OptionPanelHomePage.Controls.Add(this.PaymentUpdate);
            this.OptionPanelHomePage.Controls.Add(this.Package_Update);
            this.OptionPanelHomePage.Controls.Add(this.Dashboard);
            this.OptionPanelHomePage.Controls.Add(this.Message);
            this.OptionPanelHomePage.Controls.Add(this.Notification);
            this.OptionPanelHomePage.Location = new System.Drawing.Point(12, 12);
            this.OptionPanelHomePage.Name = "OptionPanelHomePage";
            this.OptionPanelHomePage.Size = new System.Drawing.Size(90, 623);
            this.OptionPanelHomePage.TabIndex = 1;
            // 
            // PaymentUpdate
            // 
            this.PaymentUpdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PaymentUpdate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.PaymentUpdate.FlatAppearance.BorderSize = 0;
            this.PaymentUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PaymentUpdate.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PaymentUpdate.Image = ((System.Drawing.Image)(resources.GetObject("PaymentUpdate.Image")));
            this.PaymentUpdate.Location = new System.Drawing.Point(3, 368);
            this.PaymentUpdate.Name = "PaymentUpdate";
            this.PaymentUpdate.Size = new System.Drawing.Size(84, 74);
            this.PaymentUpdate.TabIndex = 24;
            this.PaymentUpdate.Text = "Payment Update";
            this.PaymentUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PaymentUpdate.UseVisualStyleBackColor = false;
            // 
            // Package_Update
            // 
            this.Package_Update.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Package_Update.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Package_Update.FlatAppearance.BorderSize = 0;
            this.Package_Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Package_Update.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Package_Update.Image = ((System.Drawing.Image)(resources.GetObject("Package_Update.Image")));
            this.Package_Update.Location = new System.Drawing.Point(3, 268);
            this.Package_Update.Name = "Package_Update";
            this.Package_Update.Size = new System.Drawing.Size(84, 74);
            this.Package_Update.TabIndex = 23;
            this.Package_Update.Text = "Delivery Update";
            this.Package_Update.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Package_Update.UseVisualStyleBackColor = false;
            // 
            // Dashboard
            // 
            this.Dashboard.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Dashboard.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Dashboard.FlatAppearance.BorderSize = 0;
            this.Dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dashboard.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Dashboard.Image = ((System.Drawing.Image)(resources.GetObject("Dashboard.Image")));
            this.Dashboard.Location = new System.Drawing.Point(3, 530);
            this.Dashboard.Name = "Dashboard";
            this.Dashboard.Size = new System.Drawing.Size(84, 74);
            this.Dashboard.TabIndex = 22;
            this.Dashboard.Text = "Dashboard";
            this.Dashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Dashboard.UseVisualStyleBackColor = false;
            // 
            // Message
            // 
            this.Message.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Message.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Message.FlatAppearance.BorderSize = 0;
            this.Message.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Message.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Message.Image = ((System.Drawing.Image)(resources.GetObject("Message.Image")));
            this.Message.Location = new System.Drawing.Point(3, 168);
            this.Message.Name = "Message";
            this.Message.Size = new System.Drawing.Size(84, 74);
            this.Message.TabIndex = 21;
            this.Message.Text = "Message";
            this.Message.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Message.UseVisualStyleBackColor = false;
            // 
            // Notification
            // 
            this.Notification.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Notification.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Notification.FlatAppearance.BorderSize = 0;
            this.Notification.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Notification.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Notification.Image = ((System.Drawing.Image)(resources.GetObject("Notification.Image")));
            this.Notification.Location = new System.Drawing.Point(3, 68);
            this.Notification.Name = "Notification";
            this.Notification.Size = new System.Drawing.Size(84, 74);
            this.Notification.TabIndex = 20;
            this.Notification.Text = "Notification";
            this.Notification.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Notification.UseVisualStyleBackColor = false;
            this.Notification.Click += new System.EventHandler(this.Notification_Click);
            // 
            // HomePagebutton02
            // 
            this.HomePagebutton02.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.HomePagebutton02.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.HomePagebutton02.Image = ((System.Drawing.Image)(resources.GetObject("HomePagebutton02.Image")));
            this.HomePagebutton02.Location = new System.Drawing.Point(385, 112);
            this.HomePagebutton02.Name = "HomePagebutton02";
            this.HomePagebutton02.Size = new System.Drawing.Size(172, 110);
            this.HomePagebutton02.TabIndex = 2;
            this.HomePagebutton02.Text = "Outdoor";
            this.HomePagebutton02.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.HomePagebutton02.UseVisualStyleBackColor = false;
            // 
            // HomePageButton04
            // 
            this.HomePageButton04.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.HomePageButton04.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.HomePageButton04.Image = ((System.Drawing.Image)(resources.GetObject("HomePageButton04.Image")));
            this.HomePageButton04.Location = new System.Drawing.Point(385, 262);
            this.HomePageButton04.Name = "HomePageButton04";
            this.HomePageButton04.Size = new System.Drawing.Size(172, 110);
            this.HomePageButton04.TabIndex = 3;
            this.HomePageButton04.Text = "Arbor";
            this.HomePageButton04.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.HomePageButton04.UseVisualStyleBackColor = false;
            // 
            // HomePagebutton03
            // 
            this.HomePagebutton03.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.HomePagebutton03.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.HomePagebutton03.Image = ((System.Drawing.Image)(resources.GetObject("HomePagebutton03.Image")));
            this.HomePagebutton03.Location = new System.Drawing.Point(164, 262);
            this.HomePagebutton03.Name = "HomePagebutton03";
            this.HomePagebutton03.Size = new System.Drawing.Size(172, 110);
            this.HomePagebutton03.TabIndex = 4;
            this.HomePagebutton03.Text = "Medicinal";
            this.HomePagebutton03.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.HomePagebutton03.UseVisualStyleBackColor = false;
            // 
            // HomePageButton05
            // 
            this.HomePageButton05.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.HomePageButton05.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.HomePageButton05.Image = ((System.Drawing.Image)(resources.GetObject("HomePageButton05.Image")));
            this.HomePageButton05.Location = new System.Drawing.Point(164, 414);
            this.HomePageButton05.Name = "HomePageButton05";
            this.HomePageButton05.Size = new System.Drawing.Size(172, 110);
            this.HomePageButton05.TabIndex = 5;
            this.HomePageButton05.Text = "Fruits";
            this.HomePageButton05.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.HomePageButton05.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(385, 414);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(172, 110);
            this.button2.TabIndex = 6;
            this.button2.Text = "Flower";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(439, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(164, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.PlaceholderText = "Search";
            this.textBox1.Size = new System.Drawing.Size(270, 33);
            this.textBox1.TabIndex = 8;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(690, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 32);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Image = ((System.Drawing.Image)(resources.GetObject("ExitButton.Image")));
            this.ExitButton.Location = new System.Drawing.Point(690, 603);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(32, 32);
            this.ExitButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ExitButton.TabIndex = 18;
            this.ExitButton.TabStop = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // OptionView
            // 
            this.OptionView.BackColor = System.Drawing.SystemColors.Menu;
            this.OptionView.Controls.Add(this.logoutbutton);
            this.OptionView.Controls.Add(this.ManagePrf);
            this.OptionView.Controls.Add(this.ViewProfile);
            this.OptionView.Location = new System.Drawing.Point(525, 12);
            this.OptionView.Name = "OptionView";
            this.OptionView.Size = new System.Drawing.Size(159, 162);
            this.OptionView.TabIndex = 19;
            // 
            // logoutbutton
            // 
            this.logoutbutton.BackColor = System.Drawing.Color.LemonChiffon;
            this.logoutbutton.FlatAppearance.BorderSize = 0;
            this.logoutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.logoutbutton.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.logoutbutton.Location = new System.Drawing.Point(3, 100);
            this.logoutbutton.Name = "logoutbutton";
            this.logoutbutton.Size = new System.Drawing.Size(153, 42);
            this.logoutbutton.TabIndex = 2;
            this.logoutbutton.Text = "Log Out";
            this.logoutbutton.UseVisualStyleBackColor = false;
            this.logoutbutton.Click += new System.EventHandler(this.logoutbutton_Click);
            // 
            // ManagePrf
            // 
            this.ManagePrf.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ManagePrf.FlatAppearance.BorderSize = 0;
            this.ManagePrf.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ManagePrf.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ManagePrf.Location = new System.Drawing.Point(3, 52);
            this.ManagePrf.Name = "ManagePrf";
            this.ManagePrf.Size = new System.Drawing.Size(153, 42);
            this.ManagePrf.TabIndex = 1;
            this.ManagePrf.Text = "Manage Profile";
            this.ManagePrf.UseVisualStyleBackColor = false;
            this.ManagePrf.Click += new System.EventHandler(this.ManagePrf_Click);
            // 
            // ViewProfile
            // 
            this.ViewProfile.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ViewProfile.FlatAppearance.BorderSize = 0;
            this.ViewProfile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ViewProfile.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ViewProfile.Location = new System.Drawing.Point(3, 4);
            this.ViewProfile.Name = "ViewProfile";
            this.ViewProfile.Size = new System.Drawing.Size(153, 42);
            this.ViewProfile.TabIndex = 0;
            this.ViewProfile.Text = "View Profile";
            this.ViewProfile.UseVisualStyleBackColor = false;
            this.ViewProfile.Click += new System.EventHandler(this.ViewProfile_Click);
            // 
            // dataRegain
            // 
            this.dataRegain.AllowUserToAddRows = false;
            this.dataRegain.AllowUserToDeleteRows = false;
            this.dataRegain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataRegain.Location = new System.Drawing.Point(108, 625);
            this.dataRegain.Name = "dataRegain";
            this.dataRegain.ReadOnly = true;
            this.dataRegain.RowTemplate.Height = 25;
            this.dataRegain.Size = new System.Drawing.Size(13, 10);
            this.dataRegain.TabIndex = 20;
            // 
            // Homapage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(734, 647);
            this.Controls.Add(this.dataRegain);
            this.Controls.Add(this.OptionView);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.HomePageButton05);
            this.Controls.Add(this.HomePagebutton03);
            this.Controls.Add(this.HomePageButton04);
            this.Controls.Add(this.HomePagebutton02);
            this.Controls.Add(this.OptionPanelHomePage);
            this.Controls.Add(this.HomePagebutton01);
            this.Name = "Homapage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Homapage";
            this.Load += new System.EventHandler(this.Homapage_Load);
            this.OptionPanelHomePage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ExitButton)).EndInit();
            this.OptionView.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataRegain)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button HomePagebutton01;
        private System.Windows.Forms.Panel OptionPanelHomePage;
        private System.Windows.Forms.Button HomePagebutton02;
        private System.Windows.Forms.Button HomePageButton04;
        private System.Windows.Forms.Button HomePagebutton03;
        private System.Windows.Forms.Button HomePageButton05;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox ExitButton;
        private System.Windows.Forms.Panel OptionView;
        private System.Windows.Forms.Button logoutbutton;
        private System.Windows.Forms.Button ManagePrf;
        private System.Windows.Forms.Button ViewProfile;
        private System.Windows.Forms.Button PaymentUpdate;
        private System.Windows.Forms.Button Package_Update;
        private System.Windows.Forms.Button Dashboard;
        private System.Windows.Forms.Button Message;
        private System.Windows.Forms.Button Notification;
        private System.Windows.Forms.DataGridView dataRegain;
    }
}