﻿
namespace Garden_AID
{
    partial class ViewProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewProfile));
            this.panel1 = new System.Windows.Forms.Panel();
            this.AdrsView = new System.Windows.Forms.TextBox();
            this.genderView = new System.Windows.Forms.TextBox();
            this.numberDisplay = new System.Windows.Forms.TextBox();
            this.emailDisplayprf = new System.Windows.Forms.TextBox();
            this.FnDisplay = new System.Windows.Forms.TextBox();
            this.AddressView = new System.Windows.Forms.Label();
            this.genderDisplay = new System.Windows.Forms.Label();
            this.phoneNodisplay = new System.Windows.Forms.Label();
            this.EmailDisplay = new System.Windows.Forms.Label();
            this.NameLebel = new System.Windows.Forms.Label();
            this.ManagePrfSideBar = new System.Windows.Forms.Panel();
            this.locationVisiableprf = new System.Windows.Forms.TextBox();
            this.NameDisplayprf = new System.Windows.Forms.TextBox();
            this.profilePicshowerView = new System.Windows.Forms.PictureBox();
            this.WelcomeText = new System.Windows.Forms.Label();
            this.BackButtonprf = new System.Windows.Forms.Button();
            this.Logoutbutton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.ManagePrfSideBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicshowerView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.AdrsView);
            this.panel1.Controls.Add(this.genderView);
            this.panel1.Controls.Add(this.numberDisplay);
            this.panel1.Controls.Add(this.emailDisplayprf);
            this.panel1.Controls.Add(this.FnDisplay);
            this.panel1.Controls.Add(this.AddressView);
            this.panel1.Controls.Add(this.genderDisplay);
            this.panel1.Controls.Add(this.phoneNodisplay);
            this.panel1.Controls.Add(this.EmailDisplay);
            this.panel1.Controls.Add(this.NameLebel);
            this.panel1.Location = new System.Drawing.Point(260, 144);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(510, 331);
            this.panel1.TabIndex = 3;
            // 
            // AdrsView
            // 
            this.AdrsView.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.AdrsView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AdrsView.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AdrsView.Location = new System.Drawing.Point(150, 270);
            this.AdrsView.Name = "AdrsView";
            this.AdrsView.Size = new System.Drawing.Size(266, 22);
            this.AdrsView.TabIndex = 9;
            // 
            // genderView
            // 
            this.genderView.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.genderView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.genderView.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.genderView.Location = new System.Drawing.Point(150, 210);
            this.genderView.Name = "genderView";
            this.genderView.Size = new System.Drawing.Size(225, 22);
            this.genderView.TabIndex = 8;
            // 
            // numberDisplay
            // 
            this.numberDisplay.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.numberDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numberDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.numberDisplay.Location = new System.Drawing.Point(150, 150);
            this.numberDisplay.Name = "numberDisplay";
            this.numberDisplay.Size = new System.Drawing.Size(225, 22);
            this.numberDisplay.TabIndex = 7;
            // 
            // emailDisplayprf
            // 
            this.emailDisplayprf.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.emailDisplayprf.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.emailDisplayprf.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.emailDisplayprf.Location = new System.Drawing.Point(150, 90);
            this.emailDisplayprf.Name = "emailDisplayprf";
            this.emailDisplayprf.Size = new System.Drawing.Size(266, 22);
            this.emailDisplayprf.TabIndex = 6;
            // 
            // FnDisplay
            // 
            this.FnDisplay.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.FnDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FnDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FnDisplay.Location = new System.Drawing.Point(150, 30);
            this.FnDisplay.Name = "FnDisplay";
            this.FnDisplay.Size = new System.Drawing.Size(225, 22);
            this.FnDisplay.TabIndex = 5;
            // 
            // AddressView
            // 
            this.AddressView.AutoSize = true;
            this.AddressView.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AddressView.Location = new System.Drawing.Point(14, 271);
            this.AddressView.Name = "AddressView";
            this.AddressView.Size = new System.Drawing.Size(70, 21);
            this.AddressView.TabIndex = 4;
            this.AddressView.Text = "Address";
            // 
            // genderDisplay
            // 
            this.genderDisplay.AutoSize = true;
            this.genderDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.genderDisplay.Location = new System.Drawing.Point(18, 211);
            this.genderDisplay.Name = "genderDisplay";
            this.genderDisplay.Size = new System.Drawing.Size(64, 21);
            this.genderDisplay.TabIndex = 3;
            this.genderDisplay.Text = "Gender";
            // 
            // phoneNodisplay
            // 
            this.phoneNodisplay.AutoSize = true;
            this.phoneNodisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.phoneNodisplay.Location = new System.Drawing.Point(18, 151);
            this.phoneNodisplay.Name = "phoneNodisplay";
            this.phoneNodisplay.Size = new System.Drawing.Size(82, 21);
            this.phoneNodisplay.TabIndex = 2;
            this.phoneNodisplay.Text = "Phone No";
            // 
            // EmailDisplay
            // 
            this.EmailDisplay.AutoSize = true;
            this.EmailDisplay.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.EmailDisplay.Location = new System.Drawing.Point(18, 91);
            this.EmailDisplay.Name = "EmailDisplay";
            this.EmailDisplay.Size = new System.Drawing.Size(48, 21);
            this.EmailDisplay.TabIndex = 1;
            this.EmailDisplay.Text = "Email";
            // 
            // NameLebel
            // 
            this.NameLebel.AutoSize = true;
            this.NameLebel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NameLebel.Location = new System.Drawing.Point(18, 31);
            this.NameLebel.Name = "NameLebel";
            this.NameLebel.Size = new System.Drawing.Size(86, 21);
            this.NameLebel.TabIndex = 0;
            this.NameLebel.Text = "Full Name ";
            // 
            // ManagePrfSideBar
            // 
            this.ManagePrfSideBar.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ManagePrfSideBar.Controls.Add(this.locationVisiableprf);
            this.ManagePrfSideBar.Controls.Add(this.NameDisplayprf);
            this.ManagePrfSideBar.Controls.Add(this.profilePicshowerView);
            this.ManagePrfSideBar.Location = new System.Drawing.Point(3, 2);
            this.ManagePrfSideBar.Name = "ManagePrfSideBar";
            this.ManagePrfSideBar.Size = new System.Drawing.Size(212, 648);
            this.ManagePrfSideBar.TabIndex = 2;
            // 
            // locationVisiableprf
            // 
            this.locationVisiableprf.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.locationVisiableprf.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.locationVisiableprf.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.locationVisiableprf.Location = new System.Drawing.Point(17, 352);
            this.locationVisiableprf.Name = "locationVisiableprf";
            this.locationVisiableprf.Size = new System.Drawing.Size(175, 22);
            this.locationVisiableprf.TabIndex = 2;
            this.locationVisiableprf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.locationVisiableprf.TextChanged += new System.EventHandler(this.locationVisiable_TextChanged);
            // 
            // NameDisplayprf
            // 
            this.NameDisplayprf.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.NameDisplayprf.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NameDisplayprf.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.NameDisplayprf.Location = new System.Drawing.Point(17, 324);
            this.NameDisplayprf.Name = "NameDisplayprf";
            this.NameDisplayprf.Size = new System.Drawing.Size(175, 22);
            this.NameDisplayprf.TabIndex = 11;
            this.NameDisplayprf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // profilePicshowerView
            // 
            this.profilePicshowerView.Image = ((System.Drawing.Image)(resources.GetObject("profilePicshowerView.Image")));
            this.profilePicshowerView.Location = new System.Drawing.Point(17, 210);
            this.profilePicshowerView.Name = "profilePicshowerView";
            this.profilePicshowerView.Size = new System.Drawing.Size(175, 104);
            this.profilePicshowerView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.profilePicshowerView.TabIndex = 0;
            this.profilePicshowerView.TabStop = false;
            // 
            // WelcomeText
            // 
            this.WelcomeText.AutoSize = true;
            this.WelcomeText.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.WelcomeText.Location = new System.Drawing.Point(260, 40);
            this.WelcomeText.Name = "WelcomeText";
            this.WelcomeText.Size = new System.Drawing.Size(137, 25);
            this.WelcomeText.TabIndex = 4;
            this.WelcomeText.Text = "Hey, Welcome";
            // 
            // BackButtonprf
            // 
            this.BackButtonprf.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BackButtonprf.FlatAppearance.BorderSize = 0;
            this.BackButtonprf.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackButtonprf.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BackButtonprf.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackButtonprf.Location = new System.Drawing.Point(679, 607);
            this.BackButtonprf.Name = "BackButtonprf";
            this.BackButtonprf.Size = new System.Drawing.Size(91, 35);
            this.BackButtonprf.TabIndex = 0;
            this.BackButtonprf.Text = "Back";
            this.BackButtonprf.UseVisualStyleBackColor = false;
            this.BackButtonprf.Click += new System.EventHandler(this.BackButtonprf_Click);
            // 
            // Logoutbutton
            // 
            this.Logoutbutton.BackColor = System.Drawing.Color.Crimson;
            this.Logoutbutton.FlatAppearance.BorderSize = 0;
            this.Logoutbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Logoutbutton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Logoutbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Logoutbutton.Location = new System.Drawing.Point(573, 607);
            this.Logoutbutton.Name = "Logoutbutton";
            this.Logoutbutton.Size = new System.Drawing.Size(100, 35);
            this.Logoutbutton.TabIndex = 1;
            this.Logoutbutton.Text = "Log Out";
            this.Logoutbutton.UseVisualStyleBackColor = false;
            this.Logoutbutton.Click += new System.EventHandler(this.Logoutbutton_Click);
            // 
            // ViewProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 654);
            this.Controls.Add(this.Logoutbutton);
            this.Controls.Add(this.BackButtonprf);
            this.Controls.Add(this.WelcomeText);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ManagePrfSideBar);
            this.Name = "ViewProfile";
            this.Text = "ViewProfile";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ManagePrfSideBar.ResumeLayout(false);
            this.ManagePrfSideBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profilePicshowerView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox AdrsView;
        private System.Windows.Forms.TextBox genderView;
        private System.Windows.Forms.TextBox numberDisplay;
        private System.Windows.Forms.TextBox emailDisplayprf;
        private System.Windows.Forms.TextBox FnDisplay;
        private System.Windows.Forms.Label AddressView;
        private System.Windows.Forms.Label genderDisplay;
        private System.Windows.Forms.Label phoneNodisplay;
        private System.Windows.Forms.Label EmailDisplay;
        private System.Windows.Forms.Label NameLebel;
        private System.Windows.Forms.Panel ManagePrfSideBar;
        private System.Windows.Forms.TextBox locationVisiableprf;
        private System.Windows.Forms.TextBox NameDisplayprf;
        private System.Windows.Forms.PictureBox profilePicshowerView;
        private System.Windows.Forms.Label WelcomeText;
        private System.Windows.Forms.Button BackButtonprf;
        private System.Windows.Forms.Button Logoutbutton;
    }
}