﻿
namespace Garden_AID
{
    partial class IndoorPlant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IndoorPlant));
            this.Option01Indoor = new System.Windows.Forms.Button();
            this.Option2indoor = new System.Windows.Forms.Button();
            this.option3indoor = new System.Windows.Forms.Button();
            this.option4indoor = new System.Windows.Forms.Button();
            this.Option5Indoor = new System.Windows.Forms.Button();
            this.option10indoor = new System.Windows.Forms.Button();
            this.option9indoor = new System.Windows.Forms.Button();
            this.option8indoor = new System.Windows.Forms.Button();
            this.Option7indoor = new System.Windows.Forms.Button();
            this.Option6indoor = new System.Windows.Forms.Button();
            this.panelopt1 = new System.Windows.Forms.Panel();
            this.Pricetext = new System.Windows.Forms.Label();
            this.Pricerholder = new System.Windows.Forms.Label();
            this.Bar1 = new System.Windows.Forms.NumericUpDown();
            this.Quantity = new System.Windows.Forms.Label();
            this.panelopt2 = new System.Windows.Forms.Panel();
            this.Quantity02 = new System.Windows.Forms.Label();
            this.Bar2 = new System.Windows.Forms.NumericUpDown();
            this.PriceHolder02 = new System.Windows.Forms.Label();
            this.Pricetext02 = new System.Windows.Forms.Label();
            this.panelopt3 = new System.Windows.Forms.Panel();
            this.Quantity03 = new System.Windows.Forms.Label();
            this.bar03 = new System.Windows.Forms.NumericUpDown();
            this.priceHolder03 = new System.Windows.Forms.Label();
            this.Pricetext03 = new System.Windows.Forms.Label();
            this.panelopt4 = new System.Windows.Forms.Panel();
            this.quantity04 = new System.Windows.Forms.Label();
            this.bar04 = new System.Windows.Forms.NumericUpDown();
            this.priceholder4 = new System.Windows.Forms.Label();
            this.pricetext04 = new System.Windows.Forms.Label();
            this.panelopt5 = new System.Windows.Forms.Panel();
            this.quantity05 = new System.Windows.Forms.Label();
            this.bar5 = new System.Windows.Forms.NumericUpDown();
            this.priceholder5 = new System.Windows.Forms.Label();
            this.pricetext05 = new System.Windows.Forms.Label();
            this.panelopt6 = new System.Windows.Forms.Panel();
            this.quantity6 = new System.Windows.Forms.Label();
            this.bar6 = new System.Windows.Forms.NumericUpDown();
            this.priceholder6 = new System.Windows.Forms.Label();
            this.pricetext06 = new System.Windows.Forms.Label();
            this.panelopt07 = new System.Windows.Forms.Panel();
            this.quantity07 = new System.Windows.Forms.Label();
            this.bar07 = new System.Windows.Forms.NumericUpDown();
            this.priceholder7 = new System.Windows.Forms.Label();
            this.pricetext07 = new System.Windows.Forms.Label();
            this.panelopt08 = new System.Windows.Forms.Panel();
            this.quantity08 = new System.Windows.Forms.Label();
            this.bar08 = new System.Windows.Forms.NumericUpDown();
            this.priceholder08 = new System.Windows.Forms.Label();
            this.pricetext08 = new System.Windows.Forms.Label();
            this.panelopt09 = new System.Windows.Forms.Panel();
            this.quantity09 = new System.Windows.Forms.Label();
            this.bar09 = new System.Windows.Forms.NumericUpDown();
            this.priceholder09 = new System.Windows.Forms.Label();
            this.pricetext09 = new System.Windows.Forms.Label();
            this.panelopt10 = new System.Windows.Forms.Panel();
            this.quantity10 = new System.Windows.Forms.Label();
            this.bar10 = new System.Windows.Forms.NumericUpDown();
            this.priceholder10 = new System.Windows.Forms.Label();
            this.pricetext10 = new System.Windows.Forms.Label();
            this.panelopt1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Bar1)).BeginInit();
            this.panelopt2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Bar2)).BeginInit();
            this.panelopt3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar03)).BeginInit();
            this.panelopt4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar04)).BeginInit();
            this.panelopt5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar5)).BeginInit();
            this.panelopt6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar6)).BeginInit();
            this.panelopt07.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar07)).BeginInit();
            this.panelopt08.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar08)).BeginInit();
            this.panelopt09.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar09)).BeginInit();
            this.panelopt10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar10)).BeginInit();
            this.SuspendLayout();
            // 
            // Option01Indoor
            // 
            this.Option01Indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Option01Indoor.FlatAppearance.BorderSize = 0;
            this.Option01Indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Option01Indoor.Image = ((System.Drawing.Image)(resources.GetObject("Option01Indoor.Image")));
            this.Option01Indoor.Location = new System.Drawing.Point(12, 32);
            this.Option01Indoor.Name = "Option01Indoor";
            this.Option01Indoor.Size = new System.Drawing.Size(172, 110);
            this.Option01Indoor.TabIndex = 1;
            this.Option01Indoor.Text = "Money Plant";
            this.Option01Indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Option01Indoor.UseVisualStyleBackColor = false;
            // 
            // Option2indoor
            // 
            this.Option2indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Option2indoor.FlatAppearance.BorderSize = 0;
            this.Option2indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Option2indoor.Image = ((System.Drawing.Image)(resources.GetObject("Option2indoor.Image")));
            this.Option2indoor.Location = new System.Drawing.Point(12, 148);
            this.Option2indoor.Name = "Option2indoor";
            this.Option2indoor.Size = new System.Drawing.Size(172, 110);
            this.Option2indoor.TabIndex = 2;
            this.Option2indoor.Text = "Spider Plant";
            this.Option2indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Option2indoor.UseVisualStyleBackColor = false;
            // 
            // option3indoor
            // 
            this.option3indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.option3indoor.FlatAppearance.BorderSize = 0;
            this.option3indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.option3indoor.Image = ((System.Drawing.Image)(resources.GetObject("option3indoor.Image")));
            this.option3indoor.Location = new System.Drawing.Point(12, 264);
            this.option3indoor.Name = "option3indoor";
            this.option3indoor.Size = new System.Drawing.Size(172, 110);
            this.option3indoor.TabIndex = 3;
            this.option3indoor.Text = "Lucky Bamboo";
            this.option3indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.option3indoor.UseVisualStyleBackColor = false;
            // 
            // option4indoor
            // 
            this.option4indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.option4indoor.FlatAppearance.BorderSize = 0;
            this.option4indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.option4indoor.Image = ((System.Drawing.Image)(resources.GetObject("option4indoor.Image")));
            this.option4indoor.Location = new System.Drawing.Point(12, 380);
            this.option4indoor.Name = "option4indoor";
            this.option4indoor.Size = new System.Drawing.Size(172, 110);
            this.option4indoor.TabIndex = 4;
            this.option4indoor.Text = "Arica palm";
            this.option4indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.option4indoor.UseVisualStyleBackColor = false;
            // 
            // Option5Indoor
            // 
            this.Option5Indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Option5Indoor.FlatAppearance.BorderSize = 0;
            this.Option5Indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Option5Indoor.Image = ((System.Drawing.Image)(resources.GetObject("Option5Indoor.Image")));
            this.Option5Indoor.Location = new System.Drawing.Point(12, 496);
            this.Option5Indoor.Name = "Option5Indoor";
            this.Option5Indoor.Size = new System.Drawing.Size(172, 110);
            this.Option5Indoor.TabIndex = 5;
            this.Option5Indoor.Text = "Century Plant";
            this.Option5Indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Option5Indoor.UseVisualStyleBackColor = false;
            // 
            // option10indoor
            // 
            this.option10indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.option10indoor.FlatAppearance.BorderSize = 0;
            this.option10indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.option10indoor.Image = ((System.Drawing.Image)(resources.GetObject("option10indoor.Image")));
            this.option10indoor.Location = new System.Drawing.Point(440, 496);
            this.option10indoor.Name = "option10indoor";
            this.option10indoor.Size = new System.Drawing.Size(172, 110);
            this.option10indoor.TabIndex = 10;
            this.option10indoor.Text = "Zenzi ZZ";
            this.option10indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.option10indoor.UseVisualStyleBackColor = false;
            // 
            // option9indoor
            // 
            this.option9indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.option9indoor.FlatAppearance.BorderSize = 0;
            this.option9indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.option9indoor.Image = ((System.Drawing.Image)(resources.GetObject("option9indoor.Image")));
            this.option9indoor.Location = new System.Drawing.Point(440, 380);
            this.option9indoor.Name = "option9indoor";
            this.option9indoor.Size = new System.Drawing.Size(172, 110);
            this.option9indoor.TabIndex = 9;
            this.option9indoor.Text = "Snake Plant";
            this.option9indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.option9indoor.UseVisualStyleBackColor = false;
            // 
            // option8indoor
            // 
            this.option8indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.option8indoor.FlatAppearance.BorderSize = 0;
            this.option8indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.option8indoor.Image = ((System.Drawing.Image)(resources.GetObject("option8indoor.Image")));
            this.option8indoor.Location = new System.Drawing.Point(440, 264);
            this.option8indoor.Name = "option8indoor";
            this.option8indoor.Size = new System.Drawing.Size(172, 110);
            this.option8indoor.TabIndex = 8;
            this.option8indoor.Text = "Monstera";
            this.option8indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.option8indoor.UseVisualStyleBackColor = false;
            // 
            // Option7indoor
            // 
            this.Option7indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Option7indoor.FlatAppearance.BorderSize = 0;
            this.Option7indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Option7indoor.Image = ((System.Drawing.Image)(resources.GetObject("Option7indoor.Image")));
            this.Option7indoor.Location = new System.Drawing.Point(440, 148);
            this.Option7indoor.Name = "Option7indoor";
            this.Option7indoor.Size = new System.Drawing.Size(172, 110);
            this.Option7indoor.TabIndex = 7;
            this.Option7indoor.Text = "Dracaena Corn Plant";
            this.Option7indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Option7indoor.UseVisualStyleBackColor = false;
            // 
            // Option6indoor
            // 
            this.Option6indoor.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Option6indoor.FlatAppearance.BorderSize = 0;
            this.Option6indoor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Option6indoor.Image = ((System.Drawing.Image)(resources.GetObject("Option6indoor.Image")));
            this.Option6indoor.Location = new System.Drawing.Point(440, 32);
            this.Option6indoor.Name = "Option6indoor";
            this.Option6indoor.Size = new System.Drawing.Size(172, 110);
            this.Option6indoor.TabIndex = 6;
            this.Option6indoor.Text = "Rubber Plant";
            this.Option6indoor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Option6indoor.UseVisualStyleBackColor = false;
            // 
            // panelopt1
            // 
            this.panelopt1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt1.Controls.Add(this.Quantity);
            this.panelopt1.Controls.Add(this.Bar1);
            this.panelopt1.Controls.Add(this.Pricerholder);
            this.panelopt1.Controls.Add(this.Pricetext);
            this.panelopt1.Location = new System.Drawing.Point(194, 32);
            this.panelopt1.Name = "panelopt1";
            this.panelopt1.Size = new System.Drawing.Size(196, 110);
            this.panelopt1.TabIndex = 11;
            // 
            // Pricetext
            // 
            this.Pricetext.AutoSize = true;
            this.Pricetext.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Pricetext.Location = new System.Drawing.Point(4, 4);
            this.Pricetext.Name = "Pricetext";
            this.Pricetext.Size = new System.Drawing.Size(54, 21);
            this.Pricetext.TabIndex = 0;
            this.Pricetext.Text = "Price :";
            // 
            // Pricerholder
            // 
            this.Pricerholder.AutoSize = true;
            this.Pricerholder.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Pricerholder.Location = new System.Drawing.Point(64, 4);
            this.Pricerholder.Name = "Pricerholder";
            this.Pricerholder.Size = new System.Drawing.Size(19, 21);
            this.Pricerholder.TabIndex = 1;
            this.Pricerholder.Text = "P";
            // 
            // Bar1
            // 
            this.Bar1.BackColor = System.Drawing.Color.SeaShell;
            this.Bar1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Bar1.Location = new System.Drawing.Point(100, 49);
            this.Bar1.Name = "Bar1";
            this.Bar1.Size = new System.Drawing.Size(82, 25);
            this.Bar1.TabIndex = 2;
            // 
            // Quantity
            // 
            this.Quantity.AutoSize = true;
            this.Quantity.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Quantity.Location = new System.Drawing.Point(4, 51);
            this.Quantity.Name = "Quantity";
            this.Quantity.Size = new System.Drawing.Size(80, 21);
            this.Quantity.TabIndex = 3;
            this.Quantity.Text = "Quantity :";
            // 
            // panelopt2
            // 
            this.panelopt2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt2.Controls.Add(this.Quantity02);
            this.panelopt2.Controls.Add(this.Bar2);
            this.panelopt2.Controls.Add(this.PriceHolder02);
            this.panelopt2.Controls.Add(this.Pricetext02);
            this.panelopt2.Location = new System.Drawing.Point(194, 148);
            this.panelopt2.Name = "panelopt2";
            this.panelopt2.Size = new System.Drawing.Size(196, 110);
            this.panelopt2.TabIndex = 12;
            // 
            // Quantity02
            // 
            this.Quantity02.AutoSize = true;
            this.Quantity02.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Quantity02.Location = new System.Drawing.Point(4, 51);
            this.Quantity02.Name = "Quantity02";
            this.Quantity02.Size = new System.Drawing.Size(80, 21);
            this.Quantity02.TabIndex = 3;
            this.Quantity02.Text = "Quantity :";
            // 
            // Bar2
            // 
            this.Bar2.BackColor = System.Drawing.Color.SeaShell;
            this.Bar2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Bar2.Location = new System.Drawing.Point(100, 49);
            this.Bar2.Name = "Bar2";
            this.Bar2.Size = new System.Drawing.Size(82, 25);
            this.Bar2.TabIndex = 2;
            // 
            // PriceHolder02
            // 
            this.PriceHolder02.AutoSize = true;
            this.PriceHolder02.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.PriceHolder02.Location = new System.Drawing.Point(64, 4);
            this.PriceHolder02.Name = "PriceHolder02";
            this.PriceHolder02.Size = new System.Drawing.Size(19, 21);
            this.PriceHolder02.TabIndex = 1;
            this.PriceHolder02.Text = "P";
            // 
            // Pricetext02
            // 
            this.Pricetext02.AutoSize = true;
            this.Pricetext02.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Pricetext02.Location = new System.Drawing.Point(4, 4);
            this.Pricetext02.Name = "Pricetext02";
            this.Pricetext02.Size = new System.Drawing.Size(54, 21);
            this.Pricetext02.TabIndex = 0;
            this.Pricetext02.Text = "Price :";
            // 
            // panelopt3
            // 
            this.panelopt3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt3.Controls.Add(this.Quantity03);
            this.panelopt3.Controls.Add(this.bar03);
            this.panelopt3.Controls.Add(this.priceHolder03);
            this.panelopt3.Controls.Add(this.Pricetext03);
            this.panelopt3.Location = new System.Drawing.Point(194, 264);
            this.panelopt3.Name = "panelopt3";
            this.panelopt3.Size = new System.Drawing.Size(196, 110);
            this.panelopt3.TabIndex = 13;
            // 
            // Quantity03
            // 
            this.Quantity03.AutoSize = true;
            this.Quantity03.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Quantity03.Location = new System.Drawing.Point(4, 51);
            this.Quantity03.Name = "Quantity03";
            this.Quantity03.Size = new System.Drawing.Size(80, 21);
            this.Quantity03.TabIndex = 3;
            this.Quantity03.Text = "Quantity :";
            // 
            // bar03
            // 
            this.bar03.BackColor = System.Drawing.Color.SeaShell;
            this.bar03.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bar03.Location = new System.Drawing.Point(100, 49);
            this.bar03.Name = "bar03";
            this.bar03.Size = new System.Drawing.Size(82, 25);
            this.bar03.TabIndex = 2;
            // 
            // priceHolder03
            // 
            this.priceHolder03.AutoSize = true;
            this.priceHolder03.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.priceHolder03.Location = new System.Drawing.Point(64, 4);
            this.priceHolder03.Name = "priceHolder03";
            this.priceHolder03.Size = new System.Drawing.Size(19, 21);
            this.priceHolder03.TabIndex = 1;
            this.priceHolder03.Text = "P";
            // 
            // Pricetext03
            // 
            this.Pricetext03.AutoSize = true;
            this.Pricetext03.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Pricetext03.Location = new System.Drawing.Point(4, 4);
            this.Pricetext03.Name = "Pricetext03";
            this.Pricetext03.Size = new System.Drawing.Size(54, 21);
            this.Pricetext03.TabIndex = 0;
            this.Pricetext03.Text = "Price :";
            // 
            // panelopt4
            // 
            this.panelopt4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt4.Controls.Add(this.quantity04);
            this.panelopt4.Controls.Add(this.bar04);
            this.panelopt4.Controls.Add(this.priceholder4);
            this.panelopt4.Controls.Add(this.pricetext04);
            this.panelopt4.Location = new System.Drawing.Point(194, 380);
            this.panelopt4.Name = "panelopt4";
            this.panelopt4.Size = new System.Drawing.Size(196, 110);
            this.panelopt4.TabIndex = 14;
            // 
            // quantity04
            // 
            this.quantity04.AutoSize = true;
            this.quantity04.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.quantity04.Location = new System.Drawing.Point(4, 51);
            this.quantity04.Name = "quantity04";
            this.quantity04.Size = new System.Drawing.Size(80, 21);
            this.quantity04.TabIndex = 3;
            this.quantity04.Text = "Quantity :";
            // 
            // bar04
            // 
            this.bar04.BackColor = System.Drawing.Color.SeaShell;
            this.bar04.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bar04.Location = new System.Drawing.Point(100, 49);
            this.bar04.Name = "bar04";
            this.bar04.Size = new System.Drawing.Size(82, 25);
            this.bar04.TabIndex = 2;
            // 
            // priceholder4
            // 
            this.priceholder4.AutoSize = true;
            this.priceholder4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.priceholder4.Location = new System.Drawing.Point(64, 4);
            this.priceholder4.Name = "priceholder4";
            this.priceholder4.Size = new System.Drawing.Size(19, 21);
            this.priceholder4.TabIndex = 1;
            this.priceholder4.Text = "P";
            // 
            // pricetext04
            // 
            this.pricetext04.AutoSize = true;
            this.pricetext04.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pricetext04.Location = new System.Drawing.Point(4, 4);
            this.pricetext04.Name = "pricetext04";
            this.pricetext04.Size = new System.Drawing.Size(54, 21);
            this.pricetext04.TabIndex = 0;
            this.pricetext04.Text = "Price :";
            // 
            // panelopt5
            // 
            this.panelopt5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt5.Controls.Add(this.quantity05);
            this.panelopt5.Controls.Add(this.bar5);
            this.panelopt5.Controls.Add(this.priceholder5);
            this.panelopt5.Controls.Add(this.pricetext05);
            this.panelopt5.Location = new System.Drawing.Point(194, 496);
            this.panelopt5.Name = "panelopt5";
            this.panelopt5.Size = new System.Drawing.Size(196, 110);
            this.panelopt5.TabIndex = 15;
            // 
            // quantity05
            // 
            this.quantity05.AutoSize = true;
            this.quantity05.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.quantity05.Location = new System.Drawing.Point(4, 51);
            this.quantity05.Name = "quantity05";
            this.quantity05.Size = new System.Drawing.Size(80, 21);
            this.quantity05.TabIndex = 3;
            this.quantity05.Text = "Quantity :";
            // 
            // bar5
            // 
            this.bar5.BackColor = System.Drawing.Color.SeaShell;
            this.bar5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bar5.Location = new System.Drawing.Point(100, 49);
            this.bar5.Name = "bar5";
            this.bar5.Size = new System.Drawing.Size(82, 25);
            this.bar5.TabIndex = 2;
            // 
            // priceholder5
            // 
            this.priceholder5.AutoSize = true;
            this.priceholder5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.priceholder5.Location = new System.Drawing.Point(64, 4);
            this.priceholder5.Name = "priceholder5";
            this.priceholder5.Size = new System.Drawing.Size(19, 21);
            this.priceholder5.TabIndex = 1;
            this.priceholder5.Text = "P";
            // 
            // pricetext05
            // 
            this.pricetext05.AutoSize = true;
            this.pricetext05.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pricetext05.Location = new System.Drawing.Point(4, 4);
            this.pricetext05.Name = "pricetext05";
            this.pricetext05.Size = new System.Drawing.Size(54, 21);
            this.pricetext05.TabIndex = 0;
            this.pricetext05.Text = "Price :";
            // 
            // panelopt6
            // 
            this.panelopt6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt6.Controls.Add(this.quantity6);
            this.panelopt6.Controls.Add(this.bar6);
            this.panelopt6.Controls.Add(this.priceholder6);
            this.panelopt6.Controls.Add(this.pricetext06);
            this.panelopt6.Location = new System.Drawing.Point(618, 32);
            this.panelopt6.Name = "panelopt6";
            this.panelopt6.Size = new System.Drawing.Size(196, 110);
            this.panelopt6.TabIndex = 16;
            // 
            // quantity6
            // 
            this.quantity6.AutoSize = true;
            this.quantity6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.quantity6.Location = new System.Drawing.Point(4, 51);
            this.quantity6.Name = "quantity6";
            this.quantity6.Size = new System.Drawing.Size(80, 21);
            this.quantity6.TabIndex = 3;
            this.quantity6.Text = "Quantity :";
            // 
            // bar6
            // 
            this.bar6.BackColor = System.Drawing.Color.SeaShell;
            this.bar6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bar6.Location = new System.Drawing.Point(100, 49);
            this.bar6.Name = "bar6";
            this.bar6.Size = new System.Drawing.Size(82, 25);
            this.bar6.TabIndex = 2;
            // 
            // priceholder6
            // 
            this.priceholder6.AutoSize = true;
            this.priceholder6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.priceholder6.Location = new System.Drawing.Point(64, 4);
            this.priceholder6.Name = "priceholder6";
            this.priceholder6.Size = new System.Drawing.Size(19, 21);
            this.priceholder6.TabIndex = 1;
            this.priceholder6.Text = "P";
            // 
            // pricetext06
            // 
            this.pricetext06.AutoSize = true;
            this.pricetext06.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pricetext06.Location = new System.Drawing.Point(4, 4);
            this.pricetext06.Name = "pricetext06";
            this.pricetext06.Size = new System.Drawing.Size(54, 21);
            this.pricetext06.TabIndex = 0;
            this.pricetext06.Text = "Price :";
            // 
            // panelopt07
            // 
            this.panelopt07.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt07.Controls.Add(this.quantity07);
            this.panelopt07.Controls.Add(this.bar07);
            this.panelopt07.Controls.Add(this.priceholder7);
            this.panelopt07.Controls.Add(this.pricetext07);
            this.panelopt07.Location = new System.Drawing.Point(618, 148);
            this.panelopt07.Name = "panelopt07";
            this.panelopt07.Size = new System.Drawing.Size(196, 110);
            this.panelopt07.TabIndex = 17;
            // 
            // quantity07
            // 
            this.quantity07.AutoSize = true;
            this.quantity07.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.quantity07.Location = new System.Drawing.Point(4, 51);
            this.quantity07.Name = "quantity07";
            this.quantity07.Size = new System.Drawing.Size(80, 21);
            this.quantity07.TabIndex = 3;
            this.quantity07.Text = "Quantity :";
            // 
            // bar07
            // 
            this.bar07.BackColor = System.Drawing.Color.SeaShell;
            this.bar07.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bar07.Location = new System.Drawing.Point(100, 49);
            this.bar07.Name = "bar07";
            this.bar07.Size = new System.Drawing.Size(82, 25);
            this.bar07.TabIndex = 2;
            // 
            // priceholder7
            // 
            this.priceholder7.AutoSize = true;
            this.priceholder7.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.priceholder7.Location = new System.Drawing.Point(64, 4);
            this.priceholder7.Name = "priceholder7";
            this.priceholder7.Size = new System.Drawing.Size(19, 21);
            this.priceholder7.TabIndex = 1;
            this.priceholder7.Text = "P";
            // 
            // pricetext07
            // 
            this.pricetext07.AutoSize = true;
            this.pricetext07.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pricetext07.Location = new System.Drawing.Point(4, 4);
            this.pricetext07.Name = "pricetext07";
            this.pricetext07.Size = new System.Drawing.Size(54, 21);
            this.pricetext07.TabIndex = 0;
            this.pricetext07.Text = "Price :";
            // 
            // panelopt08
            // 
            this.panelopt08.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt08.Controls.Add(this.quantity08);
            this.panelopt08.Controls.Add(this.bar08);
            this.panelopt08.Controls.Add(this.priceholder08);
            this.panelopt08.Controls.Add(this.pricetext08);
            this.panelopt08.Location = new System.Drawing.Point(618, 264);
            this.panelopt08.Name = "panelopt08";
            this.panelopt08.Size = new System.Drawing.Size(196, 110);
            this.panelopt08.TabIndex = 18;
            // 
            // quantity08
            // 
            this.quantity08.AutoSize = true;
            this.quantity08.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.quantity08.Location = new System.Drawing.Point(4, 51);
            this.quantity08.Name = "quantity08";
            this.quantity08.Size = new System.Drawing.Size(80, 21);
            this.quantity08.TabIndex = 3;
            this.quantity08.Text = "Quantity :";
            // 
            // bar08
            // 
            this.bar08.BackColor = System.Drawing.Color.SeaShell;
            this.bar08.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bar08.Location = new System.Drawing.Point(100, 49);
            this.bar08.Name = "bar08";
            this.bar08.Size = new System.Drawing.Size(82, 25);
            this.bar08.TabIndex = 2;
            // 
            // priceholder08
            // 
            this.priceholder08.AutoSize = true;
            this.priceholder08.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.priceholder08.Location = new System.Drawing.Point(64, 4);
            this.priceholder08.Name = "priceholder08";
            this.priceholder08.Size = new System.Drawing.Size(19, 21);
            this.priceholder08.TabIndex = 1;
            this.priceholder08.Text = "P";
            // 
            // pricetext08
            // 
            this.pricetext08.AutoSize = true;
            this.pricetext08.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pricetext08.Location = new System.Drawing.Point(4, 4);
            this.pricetext08.Name = "pricetext08";
            this.pricetext08.Size = new System.Drawing.Size(54, 21);
            this.pricetext08.TabIndex = 0;
            this.pricetext08.Text = "Price :";
            // 
            // panelopt09
            // 
            this.panelopt09.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt09.Controls.Add(this.quantity09);
            this.panelopt09.Controls.Add(this.bar09);
            this.panelopt09.Controls.Add(this.priceholder09);
            this.panelopt09.Controls.Add(this.pricetext09);
            this.panelopt09.Location = new System.Drawing.Point(618, 380);
            this.panelopt09.Name = "panelopt09";
            this.panelopt09.Size = new System.Drawing.Size(196, 110);
            this.panelopt09.TabIndex = 19;
            // 
            // quantity09
            // 
            this.quantity09.AutoSize = true;
            this.quantity09.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.quantity09.Location = new System.Drawing.Point(4, 51);
            this.quantity09.Name = "quantity09";
            this.quantity09.Size = new System.Drawing.Size(80, 21);
            this.quantity09.TabIndex = 3;
            this.quantity09.Text = "Quantity :";
            // 
            // bar09
            // 
            this.bar09.BackColor = System.Drawing.Color.SeaShell;
            this.bar09.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bar09.Location = new System.Drawing.Point(100, 49);
            this.bar09.Name = "bar09";
            this.bar09.Size = new System.Drawing.Size(82, 25);
            this.bar09.TabIndex = 2;
            // 
            // priceholder09
            // 
            this.priceholder09.AutoSize = true;
            this.priceholder09.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.priceholder09.Location = new System.Drawing.Point(64, 4);
            this.priceholder09.Name = "priceholder09";
            this.priceholder09.Size = new System.Drawing.Size(19, 21);
            this.priceholder09.TabIndex = 1;
            this.priceholder09.Text = "P";
            // 
            // pricetext09
            // 
            this.pricetext09.AutoSize = true;
            this.pricetext09.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pricetext09.Location = new System.Drawing.Point(4, 4);
            this.pricetext09.Name = "pricetext09";
            this.pricetext09.Size = new System.Drawing.Size(54, 21);
            this.pricetext09.TabIndex = 0;
            this.pricetext09.Text = "Price :";
            // 
            // panelopt10
            // 
            this.panelopt10.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelopt10.Controls.Add(this.quantity10);
            this.panelopt10.Controls.Add(this.bar10);
            this.panelopt10.Controls.Add(this.priceholder10);
            this.panelopt10.Controls.Add(this.pricetext10);
            this.panelopt10.Location = new System.Drawing.Point(618, 496);
            this.panelopt10.Name = "panelopt10";
            this.panelopt10.Size = new System.Drawing.Size(196, 110);
            this.panelopt10.TabIndex = 20;
            // 
            // quantity10
            // 
            this.quantity10.AutoSize = true;
            this.quantity10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.quantity10.Location = new System.Drawing.Point(4, 51);
            this.quantity10.Name = "quantity10";
            this.quantity10.Size = new System.Drawing.Size(80, 21);
            this.quantity10.TabIndex = 3;
            this.quantity10.Text = "Quantity :";
            // 
            // bar10
            // 
            this.bar10.BackColor = System.Drawing.Color.SeaShell;
            this.bar10.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bar10.Location = new System.Drawing.Point(100, 49);
            this.bar10.Name = "bar10";
            this.bar10.Size = new System.Drawing.Size(82, 25);
            this.bar10.TabIndex = 2;
            // 
            // priceholder10
            // 
            this.priceholder10.AutoSize = true;
            this.priceholder10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.priceholder10.Location = new System.Drawing.Point(64, 4);
            this.priceholder10.Name = "priceholder10";
            this.priceholder10.Size = new System.Drawing.Size(19, 21);
            this.priceholder10.TabIndex = 1;
            this.priceholder10.Text = "P";
            // 
            // pricetext10
            // 
            this.pricetext10.AutoSize = true;
            this.pricetext10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pricetext10.Location = new System.Drawing.Point(4, 4);
            this.pricetext10.Name = "pricetext10";
            this.pricetext10.Size = new System.Drawing.Size(54, 21);
            this.pricetext10.TabIndex = 0;
            this.pricetext10.Text = "Price :";
            // 
            // IndoorPlant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 642);
            this.Controls.Add(this.panelopt10);
            this.Controls.Add(this.panelopt09);
            this.Controls.Add(this.panelopt08);
            this.Controls.Add(this.panelopt07);
            this.Controls.Add(this.panelopt6);
            this.Controls.Add(this.panelopt5);
            this.Controls.Add(this.panelopt4);
            this.Controls.Add(this.panelopt3);
            this.Controls.Add(this.panelopt2);
            this.Controls.Add(this.panelopt1);
            this.Controls.Add(this.option10indoor);
            this.Controls.Add(this.option9indoor);
            this.Controls.Add(this.option8indoor);
            this.Controls.Add(this.Option7indoor);
            this.Controls.Add(this.Option6indoor);
            this.Controls.Add(this.Option5Indoor);
            this.Controls.Add(this.option4indoor);
            this.Controls.Add(this.option3indoor);
            this.Controls.Add(this.Option2indoor);
            this.Controls.Add(this.Option01Indoor);
            this.Name = "IndoorPlant";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IndoorPlant";
            this.Load += new System.EventHandler(this.IndoorPlant_Load);
            this.panelopt1.ResumeLayout(false);
            this.panelopt1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Bar1)).EndInit();
            this.panelopt2.ResumeLayout(false);
            this.panelopt2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Bar2)).EndInit();
            this.panelopt3.ResumeLayout(false);
            this.panelopt3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar03)).EndInit();
            this.panelopt4.ResumeLayout(false);
            this.panelopt4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar04)).EndInit();
            this.panelopt5.ResumeLayout(false);
            this.panelopt5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar5)).EndInit();
            this.panelopt6.ResumeLayout(false);
            this.panelopt6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar6)).EndInit();
            this.panelopt07.ResumeLayout(false);
            this.panelopt07.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar07)).EndInit();
            this.panelopt08.ResumeLayout(false);
            this.panelopt08.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar08)).EndInit();
            this.panelopt09.ResumeLayout(false);
            this.panelopt09.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar09)).EndInit();
            this.panelopt10.ResumeLayout(false);
            this.panelopt10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar10)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Option01Indoor;
        private System.Windows.Forms.Button Option2indoor;
        private System.Windows.Forms.Button option3indoor;
        private System.Windows.Forms.Button option4indoor;
        private System.Windows.Forms.Button Option5Indoor;
        private System.Windows.Forms.Button option10indoor;
        private System.Windows.Forms.Button option9indoor;
        private System.Windows.Forms.Button option8indoor;
        private System.Windows.Forms.Button Option7indoor;
        private System.Windows.Forms.Button Option6indoor;
        private System.Windows.Forms.Panel panelopt1;
        private System.Windows.Forms.Label Quantity;
        private System.Windows.Forms.NumericUpDown Bar1;
        private System.Windows.Forms.Label Pricerholder;
        private System.Windows.Forms.Label Pricetext;
        private System.Windows.Forms.Panel panelopt2;
        private System.Windows.Forms.Label Quantity02;
        private System.Windows.Forms.NumericUpDown Bar2;
        private System.Windows.Forms.Label PriceHolder02;
        private System.Windows.Forms.Label Pricetext02;
        private System.Windows.Forms.Panel panelopt3;
        private System.Windows.Forms.Label Quantity03;
        private System.Windows.Forms.NumericUpDown bar03;
        private System.Windows.Forms.Label priceHolder03;
        private System.Windows.Forms.Label Pricetext03;
        private System.Windows.Forms.Panel panelopt4;
        private System.Windows.Forms.Label quantity04;
        private System.Windows.Forms.NumericUpDown bar04;
        private System.Windows.Forms.Label priceholder4;
        private System.Windows.Forms.Label pricetext04;
        private System.Windows.Forms.Panel panelopt5;
        private System.Windows.Forms.Label quantity05;
        private System.Windows.Forms.NumericUpDown bar5;
        private System.Windows.Forms.Label priceholder5;
        private System.Windows.Forms.Label pricetext05;
        private System.Windows.Forms.Panel panelopt6;
        private System.Windows.Forms.Label quantity6;
        private System.Windows.Forms.NumericUpDown bar6;
        private System.Windows.Forms.Label priceholder6;
        private System.Windows.Forms.Label pricetext06;
        private System.Windows.Forms.Panel panelopt07;
        private System.Windows.Forms.Label quantity07;
        private System.Windows.Forms.NumericUpDown bar07;
        private System.Windows.Forms.Label priceholder7;
        private System.Windows.Forms.Label pricetext07;
        private System.Windows.Forms.Panel panelopt08;
        private System.Windows.Forms.Label quantity08;
        private System.Windows.Forms.NumericUpDown bar08;
        private System.Windows.Forms.Label priceholder08;
        private System.Windows.Forms.Label pricetext08;
        private System.Windows.Forms.Panel panelopt09;
        private System.Windows.Forms.Label quantity09;
        private System.Windows.Forms.NumericUpDown bar09;
        private System.Windows.Forms.Label priceholder09;
        private System.Windows.Forms.Label pricetext09;
        private System.Windows.Forms.Panel panelopt10;
        private System.Windows.Forms.Label quantity10;
        private System.Windows.Forms.NumericUpDown bar10;
        private System.Windows.Forms.Label priceholder10;
        private System.Windows.Forms.Label pricetext10;
    }
}